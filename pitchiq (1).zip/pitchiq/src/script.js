const saveButton = document.querySelector(".submit-btn");
const matchList = document.getElementById("match-list");
saveButton.addEventListener("click", function(event) {
  event.preventDefault();
  const opponent = document.getElementById("opponent").value;
  const matchCard = document.createElement("div");
  matchCard.className = "match-card";
  matchCard.textContent = "Match vs " + opponent;
  matchList.appendChild(matchCard);
  console.log("Match added!");
});